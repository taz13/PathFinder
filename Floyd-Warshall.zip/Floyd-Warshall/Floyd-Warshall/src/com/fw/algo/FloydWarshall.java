/**
 * 
 */
package com.fw.algo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import com.google.gson.Gson;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import static java.lang.String.format;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
/**
 * @author trahman
 *
 */
public class FloydWarshall {

	/**
	 * @param args
	 */
	static String distMap= "C:/Users/trahman/Desktop/busInfo2.csv";
	static String busStopMatrix= "C:/Users/trahman/Desktop/busStops.csv";
	static BufferedReader distMatrix = null;
	static BufferedReader busStopMap = null;
    static String line = "";
    static String cvsSplitBy = ",";
	static int [][] distCost;
	static double [][]distTime;
	static String stops[];
	static String[] number;
	static int numVertices = 288;
	static ArrayList<String> pathList = new ArrayList<String>();
	static Path file = Paths.get("shortestPath.json");
	static Map<String,Map<String,String>> shortestPathMap=new HashMap<String,Map<String,String>>();
	
	public static void main(String[] args) 
	{
        distCost=new int[numVertices][numVertices];
 
        readCSV();
        floydWarshall();
	}

	//read csv file
	static void readCSV()
	{
		 try {
			 	int i=0;
	            distMatrix = new BufferedReader(new FileReader(distMap));
	            busStopMap = new BufferedReader(new FileReader(busStopMatrix));
	            line=busStopMap.readLine();
	            stops=line.split(cvsSplitBy);
	            
	            while ((line = distMatrix.readLine()) != null) {

	                // use comma as separator
	                number = line.split(cvsSplitBy);
	                
	               
	                //System.out.println("Line number: "+i+++" element number: "+number.length);
	                for(int j=0;j<number.length;j++)
	                {
	                	distCost[i][j]=Integer.parseInt(number[j]);
	                	//System.out.println("Distance from "+stops[i]+" to "+stops[j]+" : "+distCost[i][j]);
	                }
	                i++;
	            }

	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            if (distMatrix != null) {
	                try {
	                    distMatrix.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	}
	//calculates all pair shortest path
	static void floydWarshall() {
		 
 
        int[][] next = new int[numVertices][numVertices];
        for (int i = 0; i < next.length; i++) {
            for (int j = 0; j < next.length; j++)
                if (i != j)
                    next[i][j] = j + 1;
        }
 
        for (int k = 0; k < numVertices; k++)
            for (int i = 0; i < numVertices; i++)
                for (int j = 0; j < numVertices; j++)
                    if (distCost[i][k] + distCost[k][j] < distCost[i][j]) {
                    	distCost[i][j] = distCost[i][k] + distCost[k][j];
                        next[i][j] = next[i][k];
                    }
 
        printResult(next);
    }
	
    static void printResult(int[][] next) {
        System.out.println("pair     dist    path");
        for (int i = 0; i < next.length; i++) {
            for (int j = 0; j < next.length; j++) {
                if (i != j) {
                    int u = i + 1;
                    int v = j + 1;
                    String source=stops[i];
                    String destination=stops[j];
                    String path = format("%s -> %s    %2d     %s", stops[u-1],stops[v-1],
                            (int) distCost[i][j], stops[u-1]);
                    String shortestPath=stops[u-1];
                    do {
                        u = next[u - 1][v - 1];
                        path += " -> " + stops[u-1];
                        shortestPath+=":"+ stops[u-1];
                    } while (u != v);
                    
                    //System.out.println(path);
                    //pathList.add(path);
                    Map<String,String> tempMap=new HashMap<String,String>();
                    tempMap.put(Integer.toString(distCost[i][j]), shortestPath);
                    shortestPathMap.put(source+":"+destination, tempMap);
                }
            }
            
        }
        Gson gson = new Gson();
        String shortestPathJson = gson.toJson(shortestPathMap);
        pathList.add(shortestPathJson);
        try {
			Files.write(file, pathList, Charset.forName("UTF-8"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
}
